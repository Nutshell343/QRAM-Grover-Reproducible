# 中文 LaTeX 版线路可行性报告

主文件：[main.tex](main.tex)；成稿：[线路可行性_中文LaTeX报告.pdf](线路可行性_中文LaTeX报告.pdf)。

这版按“任务 → 原生门 → R5/R6节点和2态修正 → 完整query → 脉冲setup → 单节点验证 → 完整通道 → Grover → 资源与边界”重写。原生数学公式可直接编辑，25张原有数据图使用矢量PDF；未重新拟合或改变已有仿真结果。

## 编辑位置

| 文件 | 内容 |
| --- | --- |
| main.tex | 中文字体、页面、封面、阅读说明、目录 |
| sections/01_circuit.tex | 查询目标、允许门集、R5/R6、2态机制、整树顺序和理想证明 |
| sections/02_model.tex | 波形、Hamiltonian、虚拟帧、局域16态与实际往返 |
| sections/03_validation.tex | 完整query矩阵、Choi、辅助恢复、GHZ和Grover |
| sections/04_conclusion.tex | 资源、数值检查、适用边界和实验顺序 |
| sections/05_appendices.tex | 指标定义、冻结参数和四份逐门表 |
| tables/ | 从保存的JSON导出的原生TeX数表 |
| images/ | 25张矢量图；没有图片公式 |
| data/ | 主要模拟结果、冻结参数和数据来源指纹 |
| supplement/ | R5/R6整网逐层MD/JSON，以及局域门相位JSON |

正文源文件可长期直接修改。上一级`prepare_latex_report.py`只更新数表、复制图和记录指纹，不覆盖正文，不下发实验，不重新优化脉冲。

## 编译

标准方式是XeLaTeX，使用TeX Live或MiKTeX中的`ctex`、`xeCJK`、Fandol字体和常见数学排版包。该工程没有绝对图片路径，整个文件夹可以同步到其他电脑。

```powershell
Set-Location "C:\Users\qt_super\Documents\ChatGPT\TCG\Experiment\DistributedGroverNoDecoherence20261102\latex_report"
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

本机已用官方Tectonic 0.17.0成功实际编译。Codex内置预览启动编译器时出现系统访问错误，因此成稿采用本地便携编译器生成，随后用页面渲染进行检查。此问题不是TeX源码报错。

本机重建完整成稿可运行：

```powershell
.\build.ps1 -Compiler "C:\Users\qt_super\Documents\ChatGPT\TCG\tmp\latex-tools\tectonic.exe" -ReportPython "C:\Users\qt_super\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
```

Tectonic第一次可能下载所需排版包；标准XeLaTeX需要先安装相应宏包。`build.ps1`不安装或修改系统编译环境。

## 中文检索和复制

此环境的Tectonic为Fandol字体省略了PDF的`ToUnicode`映射：显示正确，但复制文字错误。因此`finalize_pdf.py`使用开放字体的CID映射补齐缺失字段，生成成稿。它不改页面内容流、公式、矢量图或排版，已验证所有页面内容流保持一致，中文能正确提取。

这个收尾步骤需要`pypdf`。原始编译文件为`main.pdf`，检查与修正后的成稿为`线路可行性_中文LaTeX报告.pdf`。普通XeLaTeX已存在的字体Unicode映射不会被替换。`pdf_checks.json`记录页数、修正字体、内容流一致性和成稿校验值。

## 数据口径

全部图是已有相干模拟，不是真机结果。不包含T1/T2耗散、附加随机门事件、准备/读出误差或有限shots重建。局域四能级脉冲和模块外理想01过程的边界在正文单独说明。输入初始化和读出开销没有混入query资源。
